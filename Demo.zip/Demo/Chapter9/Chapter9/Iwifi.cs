﻿using System;


namespace Chapter9
{
    interface Iwifi
    {
        string StartWIFI();
        string StopWIFI();
    }

    class NokiaLumia : MobilePhone, Iwifi
    {
         public string StartWIFI()
        {
            return "Starting WiFi";
        }

        public string StopWIFI()
        {
            return "Stop WiFi";
        }

        public int Price()
        {
            return 9999;
        }

    }

    class NokiaLumia2:NokiaLumia
    {
        public string PushMessage()
        {
            return "Calling from NokiaLumia2.PushMessage()";
        }
    }

    class InterfaceDamo
    {
        static void Main()
        {
           // Iwifi i = new NokiaLumia();
            NokiaLumia2 nl = new NokiaLumia2();
            Console.WriteLine(nl.StartWIFI());
            Console.WriteLine(nl.StopWIFI());
            Console.WriteLine(nl.Calling());
            Console.WriteLine(nl.PushMessage());
            Console.WriteLine(nl.Price());
            //Console.WriteLine(i.StartWIFI());
            //Console.WriteLine(i.StopWIFI());
        }
    }
}
