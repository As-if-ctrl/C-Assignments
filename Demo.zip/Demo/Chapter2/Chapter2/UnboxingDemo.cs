﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class UnboxingDemo
    {
        static void Main()
        {
            Object obj = 30;
            int i = (int)obj;
            Console.WriteLine(i);
            Console.ReadLine();
        }
    }
}
