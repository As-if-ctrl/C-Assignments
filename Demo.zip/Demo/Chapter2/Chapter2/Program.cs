﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    /// <summary>
    /// This is simple class.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            //single line comment
           /*
            * 
            * 
            * 
            */
        }
        /// <summary>
        /// This fuction prints a test message.
        /// </summary>
        public void Message()
        {
            Console.WriteLine("Hello World");
        }
        /// <summary>
        /// This function accepts text and print text
        /// </summary>
        /// <param name="str">simple text</param>
        /// <returns></returns>
        public string Message(string str)
        {
            return str;
        }
    }
}
