﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9.Properties
{
    public abstract class Vehical
    {
        public Vehical()
        {
            Console.WriteLine("Default vehical constructor");
        }

        public string Start()
        {
            return "Starting Vehical";
        }

        public string Stop()
        {
            return "Stoping vehical";
        }
        public abstract string Start(string type);
    }

    partial class FourWheelar : Vehical
    {
        public FourWheelar()
        {

        }
        public override string Start(string type)
        {
            return $"This will start using {type}";
        }
    }
    partial class FourWheelar
    {
        public FourWheelar(int model)
        {

        }
    }

    class AbstractDemo
    {
        static void Main()
        {
            //Vehical v = new Vehical();//doesn't create object of abstract class
            FourWheelar fw = new FourWheelar();
            Console.WriteLine(fw.Start());
            Console.WriteLine(fw.Stop());
            Console.WriteLine(fw.Start("key"));

        }
    }
}
