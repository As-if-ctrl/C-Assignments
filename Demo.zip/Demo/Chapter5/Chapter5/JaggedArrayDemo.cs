﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class JaggedArrayDemo
    {
        static void Main()
        {
            int[][] nums = new int[2][];
            nums[0] = new int[] { 10, 20, 30 };
            nums[1] = new int[] { 40, 50 };
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in nums[i])
                {
                    Console.Write("{0}\t", temp);
                }
              
                Console.WriteLine();

            }
        } 
    }
}
