﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==========For Loop=========");
            int sum = 0;
            for(int i = 0; i <= 15; i++)
            {
                sum += i;
                Console.WriteLine(sum);
            }

            Console.WriteLine("==========While Loop============");
            int j = 0;
            sum = 0;
            while (j <= 15)
            {
                sum += j;
                Console.WriteLine(sum);
                j++;
            }

            Console.WriteLine("==========Do While Loop============");
            sum = 0;
            do
            {
                sum += j;
                Console.WriteLine(sum);
                j++;
            }
            while (j <= 15);
            Console.ReadLine();
        }
    }
}
