﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class Program
    {
        static void Main(string[] args)
        {
            CreatMobilePhone();
            GC.Collect();
            Console.ReadLine();
        }
        public static void CreatMobilePhone()
        {
            MobilePhone m = new MobilePhone();
            MobilePhone m1 = new MobilePhone(1001, "Note 7", "MI12345");
            
            Console.ReadLine();
        }
    }
}
