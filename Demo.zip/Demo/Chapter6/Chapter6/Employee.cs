﻿using Chapter6.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Employee
    {
        public void PrintName(string name)
        {
            if (name == "")
            {
                throw new NullReferenceException("Employee Name is null");
            }
        }

        public void ValidateEmpCode(int EmpCode)
        {
            if (EmpCode <= 0)
            {
                throw new InvalidEmployeeCode();
            }
        }


    }
}
