﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class User
    {
        private long u_Id;
        private string u_Name;
        private string u_EmailId;
        private string u_DateofBirth;
        

        public User()
        {
            Console.WriteLine("Please fill the information about User:");
        }

        public User(long u_Id, string u_Name, string u_EmailId, string u_DateofBirth)
        {
            this.u_Id = u_Id;
            this.u_Name = u_Name;
            this.u_EmailId = u_EmailId;
            this.u_DateofBirth = u_DateofBirth;

        }

        public long User_id
        {
            get
            {
                return u_Id;
            }
        }

        public string User_Name
        {
            get
            {
                return u_Name;
            }
        }

        public string User_EmailId
        {
            
            get
            {
                return u_EmailId;
            }
        }

        public override string ToString()
        {
            return string.Format("Id = {0} \nName = {1} \nEmail Id = {2} \nDate of Birth = {3} ",u_Id,u_Name,u_EmailId,u_DateofBirth);
        }
    }
}
