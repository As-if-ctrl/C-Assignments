﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class CityMain
    {
        static void Main()
        {
            foreach (string city in Enum.GetNames(typeof(CitySTDcode.city)))
            {
                Console.WriteLine("Name of Citys = {0}",city);
            }
            foreach (int code in Enum.GetValues(typeof(CitySTDcode.city)))
            {
                Console.WriteLine("STD code of Citys = {0}",code);
            }
        }

    }
}
