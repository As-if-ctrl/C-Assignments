﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class throwExceptionDemo
    {
        static void Main()
        {
            try
            {
                Employee e = new Employee();
                e.PrintName("");
            }
            catch(NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
       
        }
    }
}
