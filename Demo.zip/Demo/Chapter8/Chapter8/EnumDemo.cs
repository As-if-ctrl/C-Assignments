﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class EnumDemo
    {
        static void Main()
        {
            //Console.WriteLine(Colors.red.GetHashCode());// Convert.ToInt32(Colors.red)
            //Console.WriteLine(Colors.blue);
            //Console.WriteLine(Colors1.red);
            //Console.WriteLine(GST.Maharastra.GetHashCode());
            foreach (string name in Enum.GetNames(typeof(GST)))
            {
                Console.WriteLine(name);
            }
            foreach (int code in Enum.GetValues(typeof(GST)))
            {
                Console.WriteLine(code);
            }
            Console.ReadLine();
        }
    }
}
