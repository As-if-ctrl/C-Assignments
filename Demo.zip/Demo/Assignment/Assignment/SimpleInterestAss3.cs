﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SimpleInterestAss3
    {
        public double PayableAmount( double rate, double amount, double time, out double Interest)
        {
            Interest = amount * rate * time / 100;
            double TotalAmount = amount + Interest;
            return TotalAmount;
        }

        public double simpleInterest(double rate, double amnt, double time)
        {
            double SI = amnt * rate * time / 100;
            return SI;
        }

        static void Main()
        {
            SimpleInterestAss3 si = new SimpleInterestAss3();
            double interest;

            Console.WriteLine("Enter the interest rate");
            double r = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Amount :");
            double Amt = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Time");
            double time = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Total amount with intrest {0}",si.PayableAmount(r,Amt,time, out interest));
            Console.WriteLine($"Simple interest amount is {interest}");

            Console.WriteLine();
            Console.WriteLine("===========Assignment3==========");
            Console.WriteLine();
            Console.WriteLine("Enter the interest rate");
            double r1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Amount :");
            double Amt1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Time");
            double time1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Simple Interest: {0}",si.simpleInterest(r1, Amt1, time1));
     
        }
    }
}
