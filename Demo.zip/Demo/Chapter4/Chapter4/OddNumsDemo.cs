﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class OddNumsDemo
    {
        static void Main()
        {
            int[] arr = { 1, 2, 23, 5, 45, 34, 88, 37, 92, 3, 4 };
            var v = arr;
            foreach(var temp in v)
            {
                if (temp % 2 != 0)
                {
                    Console.WriteLine(temp);
                }
            }
            Console.ReadLine();
        }
    }
}
