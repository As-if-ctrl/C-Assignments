﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class PropertiesDemo
    {
        static void Main()
        {
            Student std = new Student() {StdRollNo=100, StdName="Scott" };///autoproperty initializer
           // std.StdRollNo = 0;
            //std.StdName = "Scott";
            Console.WriteLine($"{std.StdRollNo} {std.StdName}");
        }
    }
}
