﻿using System;


namespace Assignment2
{
    class RoomMain
    {
        static void Main(string[] args)
        {
            Room r = new Room();
            Console.WriteLine("Enter Room Number :");
            int r_no = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Floor Number :");
            int f_no = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Room Type :");
            string r_type = Console.ReadLine();

            Console.WriteLine("Enter Room Capacity :");
            int r_capsty = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Room Booked Date :");
            DateTime r_bt = DateTime.Parse(Console.ReadLine());

            Console.WriteLine("Enter Room Price :");
            double r_p = Convert.ToDouble(Console.ReadLine());

            Room r1 = new Room(r_no, f_no, r_capsty, r_type, r_p, r_bt);

            Console.WriteLine(r1.ToString());
            Console.ReadLine();
        }
    }
}
