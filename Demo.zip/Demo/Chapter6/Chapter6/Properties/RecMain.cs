﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6.Properties
{
    class RecMain
    {
        static void Main()
        {
            SettingsDemo s = new SettingsDemo();
            s.MyRecFun(1);
        }
    }
}
