﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class Class1
    {
        static void Main()
        {
            Program p = new Program();
            Console.WriteLine( p.Message("Hello World"));
            p.Message();
            Console.ReadLine();
        }
    }

    class Class2:Class1
    {

    }
}
