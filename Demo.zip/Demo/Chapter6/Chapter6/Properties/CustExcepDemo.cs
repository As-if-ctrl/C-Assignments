﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6.Properties
{
    class CustExcepDemo
    {
        static void Main()
        {
            try
            {
                Employee e = new Employee();
                e.ValidateEmpCode(0);
            }
            catch(InvalidEmployeeCode ex)
            {
                Console.WriteLine(ex.Message);
            }
           

        }
    }
}
