﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class Nokia1400:MobilePhone
    {
        public Nokia1400()
        {
            Console.WriteLine("Default constructor of Nokia1400");
        }

        public string Radio()
        {
            return "Calling radio from Nokia1400";
        }

        ~Nokia1400()
        {
            Console.WriteLine("Garbage is collected for Nokia1400 instans");
        }
    }
}
