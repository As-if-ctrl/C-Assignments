﻿using System;
using GST;

namespace Assignment2
{
    class GSTCalculation
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter item:(Food | Services | Ornments)");
            string item = Console.ReadLine();

            double rate;

            Console.WriteLine("Enter  Amount");
            double amount = Convert.ToDouble(Console.ReadLine());

            switch (item)
            {
                case "Food":
                    rate = 5;
                    break;

                case "Services":
                    rate = 12;
                    break;

                case "Ornments":
                    rate = 18;
                    break;
                default:
                    rate = 24;
                    break;
            }


            GSTExtention gst = new GSTExtention(rate, amount);
            Console.WriteLine(gst.Display());
            Console.ReadLine();

        }
    }
}
