﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9.Properties
{
    static class Employee
    {
        static Employee()
        {
            Console.WriteLine("Default constructor of employee");
        }

        public static string Details(int EmpCode, string Name)
        {
            return string.Format("Employee Code is {0} and Name is {1}", EmpCode, Name);
        }
    }
}
