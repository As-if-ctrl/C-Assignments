﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 10, 20, 30, 40, 50 };
            int[] nums1 = new int[] { 10, 20, 30, 40, 50 };
            Console.WriteLine("Size of nums1 is {0}", nums1.Length);
            for(int i = 0; i <= (nums1.Length - 1); i++)
            {
                Console.WriteLine(nums1[i]);
            }
            int[] num2 = new int[5];
            Console.WriteLine("Enter the elements in array");
            for(int i=0; i < 5; i++)
            {
                num2[i] = Convert.ToInt32(Console.ReadLine());
            }
            foreach(int temp in num2)
            {
                Console.WriteLine(temp);
            }
            Console.ReadLine();
        }
    }
}
