﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class Program
    {
        static void Main(string[] args)
        {
            Book mybook = new Book(123, "C# 4.0", "Donis Marsh");
            Console.WriteLine($"{mybook.Display()}");

        }
    }
}
