﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class GradesAss2
    {
        static void Main()
        {
            Console.WriteLine("Enter the percentage :");
            double percent = Convert.ToDouble(Console.ReadLine());
            if (percent > 65)
            {
                Console.WriteLine("Grade A+");
            }
            else if (percent > 60)
            {
                Console.WriteLine("Grade A");
            }
            else if (percent > 55)
            {
                Console.WriteLine("Grade B+");
            }
            else if (percent > 50)
            {
                Console.WriteLine("Grade B");
            }
            else
            {
                Console.WriteLine("Grade C");
            }
        }
    }
}
