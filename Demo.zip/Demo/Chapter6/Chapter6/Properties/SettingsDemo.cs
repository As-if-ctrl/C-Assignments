﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6.Properties
{
    class SettingsDemo
    {
        static void Main()
        {
            Login();
            UserDetails();
        }
        public static void Login()
        {
            Chapter6.Properties.Settings1.Default.UserName = "Scott";
        }
        public static void UserDetails()
        {
            string name = Chapter6.Properties.Settings1.Default.UserName;
            Console.WriteLine("welcome :{0}", name);
        }
        public static void MyFun(int x)
        {
            if (true)
            {
                int y = 20;
            }
        }

        public void MyRecFun(int x)
        {
            if(x<=10)
            {
                Console.WriteLine(x);
                x++;
                MyRecFun(x);
            }        }
    }
}
