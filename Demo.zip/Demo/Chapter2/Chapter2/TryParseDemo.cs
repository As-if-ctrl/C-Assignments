﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class TryParseDemo
    {
        static void Main()
        {
            string str = "sdfg";
            int outvar;
            bool IsComp = int.TryParse(str, out outvar);
            if (IsComp)
            {
                Console.WriteLine(outvar);
            }
            else
            {
                Console.WriteLine("Conversion is not compitible");
            }
            Console.ReadLine();
        }
    }
}
