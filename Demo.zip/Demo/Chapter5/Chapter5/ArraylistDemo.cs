﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class ArraylistDemo
    {
        static void Main()
        {
            ArrayList std = new ArrayList();
            std.Add(100);
            std.Add("scott");
            std.Add("scott@gmail.com");
            std.Add('M');
            std.Add(true);
            std.Capacity = std.Count;
            Console.WriteLine("Total count is {0} Capcity {1}", std.Count,std.Capacity);
            foreach(var temp in std)
            {
                Console.WriteLine(temp);
            }
            std.Remove("scott");
            std.Capacity = std.Count;
            Console.WriteLine("After removing name");
            foreach(var temp in std)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("Total count is {0} Capcity {1}", std.Count, std.Capacity);
            Console.WriteLine("100 is there? {0}", std.Contains(100));
            std.Clear();
            Console.WriteLine("After removing all elements :");
            std.Capacity = std.Count;
            Console.WriteLine("Total count is {0} Capcity {1}", std.Count, std.Capacity);
        }
    }
}
