﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class Student
    {

        private int Roll_No;
        private string Name;

        public int StdRollNo
        {
            get
            {
                Roll_No++;
                return Roll_No;
            }
            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("Invalid Roll No");
                }
                else
                {
                    Roll_No = value;
                }
                
            }
        }

        public string StdName
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }

        public string SchoolName
        {

            get
            {
                return "MH";
            }
        }
    }
}
