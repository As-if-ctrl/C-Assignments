﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class GSTDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter item:(Food | Services | Ornments)");
            string item = Console.ReadLine();
            Console.WriteLine("Enter the amount of item:");
            double amount = Convert.ToDouble(Console.ReadLine());
            double totalAmount;
            if (item == "Food")
            {
                double gst = (amount * 5 / 100);
                totalAmount = gst + amount;
                Console.WriteLine(totalAmount);
            }
            else if(item == "Services")
            {
                Console.WriteLine("4%");
            }
            else if (item == "Ornments")
            {
                Console.WriteLine("12%");
            }
            else
            {
                Console.WriteLine("Invalid item");
            }
            Console.ReadLine();

        }
    }
}
