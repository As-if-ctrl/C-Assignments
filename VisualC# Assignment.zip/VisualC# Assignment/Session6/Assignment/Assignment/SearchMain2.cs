﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SearchMain2
    {
        static void Main()
        {
            SearchElementAss2 se = new SearchElementAss2();
            int[][] arr = new int[2][];
            arr[0] = new int[3] { 10, 50, 24 };
            arr[1] = new int[4] { 45, 65, 42, 12 };

            Console.WriteLine("Enter the search element:");
            int num = Convert.ToInt32(Console.ReadLine());
            se.JaggedSearch(arr, num);
        }
    }
}
