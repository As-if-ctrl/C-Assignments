﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    enum Colors
    {
        red,green=200,blue=red
    }
    enum Colors1
    {
        red=Colors.green,green=200,blue=Colors.blue
    }
    enum GST
    {
        Maharastra=27,Gujrat=24,Dehli=12,UP=30,MP=32,AP=40,Karnatka=28
    }
}
