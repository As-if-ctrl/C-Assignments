﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class NestedIfDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter higher qualification (UG | PG)");
            string qualification = Console.ReadLine();
            Console.WriteLine("Enter experience in months:");
            int Month = Convert.ToInt32(Console.ReadLine());
            if(qualification == "PG")
            {
                if(Month >= 12)
                {
                    Console.WriteLine("you are eligible for interview");
                }
                else
                {
                    Console.WriteLine("Exp should greater than equal to 12 Months");
                }
            }
            else
            {
                Console.WriteLine("Qualification should be PG");
            }
            Console.ReadLine();
        }
    }
}
