﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class TernaryDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter annual income in Rupees:");
            int Annualincome = Convert.ToInt32(Console.ReadLine());
            string result = Annualincome >= 250000 ? "you are liable to pay I.T." : "you are not liable to pay I.T.";
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
