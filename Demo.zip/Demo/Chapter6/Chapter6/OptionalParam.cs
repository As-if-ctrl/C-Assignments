﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class OptionalParam
    {
        static void Main()
        {
            MyMath m = new MyMath();
            // Console.WriteLine("Size is {0}",m.Size(20)); //second param is optional to give or not give dosen,t matter it take default value
            Console.WriteLine( m.Size(20,  msg:"This is Answer:"));//name param pass with name of parameter and give to value
        }
    }
}
