﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class InterestMain4
    {
        static void Main()
        {
            SimpleInterestAss4 si = new SimpleInterestAss4();
            double interest;

            Console.WriteLine("Enter the interest rate");
            double r = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Amount :");
            double Amt = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Time");
            double time = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Total amount with intrest {0}", si.PayableAmount(r, Amt, time, out interest));
            Console.WriteLine($"Simple interest amount is {interest}");

           
           

        }
    }
}
