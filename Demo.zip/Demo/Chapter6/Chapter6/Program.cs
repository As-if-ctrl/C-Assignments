﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Program
    {
        static void Main(string[] args)
        {
            MyMath m = new MyMath();
            m.Message();
            int sum = m.Add(12, 12);
            Console.WriteLine(sum);
        }
    }
}
