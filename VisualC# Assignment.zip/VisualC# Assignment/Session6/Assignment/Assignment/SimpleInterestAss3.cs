﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SimpleInterestAss3
    {
        public double simpleInterest(double rate, double amnt, double time)
        {
            double SI = amnt * rate * time / 100;
            return SI;
        }
        
        static void Main()
        {
            SimpleInterestAss3 si = new SimpleInterestAss3();

            Console.WriteLine("Enter the interest rate");
            double r1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Amount :");
            double Amt1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Time");
            double time1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Simple Interest: {0}", si.simpleInterest(r1, Amt1, time1));
            Console.ReadLine();
        }
    }
}
