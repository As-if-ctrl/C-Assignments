﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9.Properties
{
    class StaticDemo
    {
        static void Main()
        {
            Console.WriteLine(Employee.Details(101, "Tiger"));

        }
    }
}
