﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class MyDateMain
    {
        static void Main()
        {
            
            foreach(string months in Enum.GetNames(typeof(MyDate.MyMonths.Months)))
            {
                Console.WriteLine($"{months}");
            }
            foreach(int year in Enum.GetValues(typeof(MyDate.MyYears.Years)))
            {
                Console.WriteLine(year);
            }
        }
    }
}
