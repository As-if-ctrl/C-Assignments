﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class StudentMain
    {
        static void Main()
        {
            Student s = new Student(101, "Asif", "Male", 8805560869);
            Console.WriteLine(s.display());
        }
    }
}
