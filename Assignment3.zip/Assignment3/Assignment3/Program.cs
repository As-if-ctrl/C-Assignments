﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Calling default constructor
            User u = new User();

            //Pass the user details from user
            Console.WriteLine("Enter User Id:");
            long id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter User Name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter User Email Id:");
            string email = Console.ReadLine();

            Console.WriteLine("Enter User Date of Birth:");
            string DoB = Console.ReadLine();

            //calling parameterised constructor and set the value
            User u1 = new User(id, name, email, DoB);

            Console.WriteLine("\nShow the details of user:");
            Console.WriteLine(u1.ToString());
            Console.ReadLine();


        }
    }
}
