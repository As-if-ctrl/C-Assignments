﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class MobilePhone
    {
        int ModelNo;
        string ModelName;
        string IMEINo;

        public MobilePhone()
        {
            Console.WriteLine("Default constructor of mobile phone");
        }

        public MobilePhone(int ModelNo, string ModelName, string IMEINo)
        {
            this.ModelNo = ModelNo;
            this.ModelName = ModelName;
            this.IMEINo = IMEINo;
        }

        public override string ToString()
        {
            return string.Format("Model No: {0} Model Name : {1} IMEI No : {2}",ModelNo,ModelName, IMEINo);
        }

        public string Calling()
        {
            return "This is Calling form mobile Phone";
        }

        public string SMS()
        {
            return "Sending Msg form Mobile Phone";
        }

        ~MobilePhone()
        {
            Console.WriteLine("Garbaje is collected ");
        }
    }
}
