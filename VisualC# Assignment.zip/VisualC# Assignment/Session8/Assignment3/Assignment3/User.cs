﻿using System;


namespace Assignment3
{
    class User
    {
        private long u_Id;
        private string u_Name;
        private string u_EmailId;
        private string u_DateofBirth;
        

        public User()
        {
            Console.WriteLine("Please fill the information about User:");
        }

        public User(long u_Id, string u_Name, string u_EmailId, string u_DateofBirth)
        {
            this.u_Id = u_Id;
            this.u_Name = u_Name;
            this.u_EmailId = u_EmailId;
            this.u_DateofBirth = u_DateofBirth;



        }



        public override string ToString()
        {
            return string.Format("Id = {0} \nName = {1} \nEmail Id = {2} \nDate of Birth = {3} ", u_Id, u_Name, u_EmailId, u_DateofBirth);
        }
    }
}
