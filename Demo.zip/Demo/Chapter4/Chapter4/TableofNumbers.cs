﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class TableofNumbers
    {
        static void Main()
        {
            Console.WriteLine("Enter the number");
            int num = Convert.ToInt32(Console.ReadLine());
            int table;
            Console.WriteLine("Table of {0}", num);
            for (int i = 1; i <=10; i++)
            {
                table = i * num;
                Console.WriteLine(table);
            }
           
        }
    }
}
