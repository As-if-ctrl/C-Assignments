﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class AsDemo
    {
        static void Main()
        {
            object[] obj = { 10, 20, "abc" };
            string str = obj[2] as string;
            if(str != null)
            {
                Console.WriteLine("abc");
            }
            Console.ReadLine();
            
        }
    }
}
