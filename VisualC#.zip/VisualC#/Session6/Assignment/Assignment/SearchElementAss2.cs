﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SearchElementAss2
    {
        //Calling JaggedSearch function from SearchMain Class
        public int JaggedSearch(int[][] arr, int num)
        {
            int flag = -1;
            for (int i = 0; i < arr.Length; i++)
            {

                foreach (int temp in arr[i])
                {
                    if (temp == num)
                    {
                        flag = 1;
                    }
                }

            }
            if (flag == 1)
            {
                Console.WriteLine("Element is found");
            }
            else
            {
                Console.WriteLine("Element is not found");
            }
            Console.ReadLine();
            return 0;
        }
    }
}
