﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter annual income in Rupees:");
            int Annualincome = Convert.ToInt32(Console.ReadLine());
            if(Annualincome >= 250000)
            {
                Console.WriteLine("you are libale to pay I.T");

            }
            else
            {
                Console.WriteLine("you are not libale to pay I.T");
            }
        }
    }
}
