﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class ForEachDemo
    {
        static void Main()
        {
            string[] names = { "sachin", "Rahul", "Saurav", "Zaheer", "Virat" };
            foreach(string temp in names)
            {
                if (temp == "VIrat")
                {
                    Console.WriteLine("Virat is captain");
                }
                else
                {
                    Console.WriteLine(temp);
                }
                
            }

            for(int i=0; i < 5; i++)
            {
                Console.WriteLine(names[i]);
            }

            int[] nums = { 12, 23, 34, 45 };
            foreach(int temp in nums)
            {
                Console.WriteLine(temp);
            }

            object[] obj = { 12, 23, "asd", 'A', true };
            var v = obj;
            foreach(var temp in v)
            {
                Console.WriteLine(temp);
            }
            Console.ReadLine();
        }
    }
}
