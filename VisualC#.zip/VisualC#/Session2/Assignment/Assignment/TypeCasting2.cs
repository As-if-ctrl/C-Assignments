﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class TypeCasting2
    {
        static void Main()
        {
            Console.WriteLine("Enter dollar amount:");
            int Dollar = Convert.ToInt32(Console.ReadLine());
            double rupees = Convert.ToDouble(Dollar * 71.06);
            Console.WriteLine("Enter Rupees amount:");
            int Rupees = Convert.ToInt32(Console.ReadLine());
            double dollar = Rupees / 71.06;
            Console.WriteLine("{0} $ is equal to {1} Rupees", Dollar, rupees);
            Console.WriteLine("{0} Rupees is equal to {1} $", Rupees, dollar);
            Console.ReadLine();
        }
    }
}
