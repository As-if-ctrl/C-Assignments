﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6.Properties
{
    class StudentExcepDemo
    {
        static void Main()
        {
            try
            {
                Student std = new Student();
                std.StudentDetails(101, "");
                
            }
            catch(InvalidStudentCode ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
        
    }
}
