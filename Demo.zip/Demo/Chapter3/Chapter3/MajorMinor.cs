﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class MajorMinor
    {
        static void Main()
        {
            Console.WriteLine("Enter the age of person:");
            int person = Convert.ToInt32(Console.ReadLine());
            if (person >= 18)
            {
                Console.WriteLine("Person is Major");
            }
            else
            {
                Console.WriteLine("Person is Minor");
            }
        }
    }
}
