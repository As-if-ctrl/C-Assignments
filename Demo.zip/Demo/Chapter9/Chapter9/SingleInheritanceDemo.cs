﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class SingleInheritanceDemo
    {
        static void Main()
        {
            Create();
            GC.Collect();

           
            Console.ReadLine();            

        }

        public static void Create()
        {
            Nokia1400 nk = new Nokia1400();
            Console.WriteLine(nk.Calling());
            Console.WriteLine(nk.SMS());
        }
    }
}
