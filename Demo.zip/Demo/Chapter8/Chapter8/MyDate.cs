﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    struct MyDate
    {
        public struct MyMonths
        {
            public enum Months
            {
                Jan = 1, Feb = 2, Mar = 3, Apr = 4, May = 5, Jun = 6, July = 7, Aug = 8, Sep = 9, Oct = 10, Nov = 11, Des = 12
            }
        }
           
        public struct MyYears
        {
            public enum Years
            {
                Year1 = 2019, Year2 = 2020, Year3 = 2021
            }
        }

       
           
       

    }
}
