﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class MultilevelDemo
    {
        static void Main()
        {
            Create();
            GC.Collect();
            Console.ReadLine();
        }

        public static void Create()
        {
            Nokia1100 nk =new Nokia1100();
            Console.WriteLine(nk.MP3());
            Console.WriteLine(nk.Calling());
        }
    }
}
