﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class SumOfRowAss4
    {
        /// <summary>
        /// Sum of Each Row
        /// </summary>
        static void Main()
        {
            int row1 = 0;
            int row2 = 0;
            int row3 = 0;
            int[,] arr = { { 10, 40, 50 }, { 60, 20, 70 }, { 80, 90, 30 } };
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (i == 0)
                    {
                        row1 = row1 + arr[i, j];
                    }
                    else if (i == 1)
                    {
                        row2 = row2 + arr[i, j];
                    }
                    else
                    {
                        row3 = row3 + arr[i, j];
                    }
                }
            }
            Console.WriteLine("Sum of row1 {0}", row1);
            Console.WriteLine("Sum of row2 {0}", row2);
            Console.WriteLine("Sum of row3 {0}", row3);
            Console.ReadLine();
        }
    }
}
