﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class HastableDemo
    {
        static void Main()
        {
            Hashtable gst = new Hashtable();
            gst.Add("maharastra", 27);
            gst.Add("gujarat", 24);
            gst.Add("delhi", 12);
            string state = "Gujarat";
            if (gst[(state).ToLowerInvariant()] == null)
            {
                Console.WriteLine("Invalid State");
            }
            else
            {
                Console.WriteLine("gst code for Gujarat is {0}", gst[(state).ToLowerInvariant()]);
            }

            gst["delhi"] = 11;
            Console.WriteLine("gst code for Delhi is {0}", gst[("Delhi").ToLowerInvariant()]);
            Console.WriteLine("All keys from gst");
            foreach(var v in gst.Keys)
            {
                Console.WriteLine("key={0} and value={1}",v,gst[v]);
            }

            gst.Remove("delhi");
            Console.WriteLine("After removing delhi");
            foreach (var v in gst.Keys)
            {
                Console.WriteLine("key={0} and value={1}", v, gst[v]);
            }

        }
    }
}
