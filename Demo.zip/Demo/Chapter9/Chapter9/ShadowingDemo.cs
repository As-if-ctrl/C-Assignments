﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class ShadowingDemo
    {
        static void Main()
        {
            MyMath3 m = new MyMath3();
            Console.WriteLine(m.Increment(5));
            Console.WriteLine(m.Add("5","9"));
        }
    }
}
