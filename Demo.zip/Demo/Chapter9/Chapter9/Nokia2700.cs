﻿using System;


namespace Chapter9
{
    class Nokia2700:MobilePhone
    {
        public Nokia2700()
        {
            Console.WriteLine("Default constructor of Nokia2700");
        }

        public string MP4()
        {
            return "MP4 Calling from Nokia2700";
        }

        public string Camera()
        {
            return "Camera Calling from Nokia2700";
        }
    }
}
