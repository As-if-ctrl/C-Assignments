﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class GSTCalulationDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            double amount;
            Console.WriteLine("Amount of GST {0}",m.GST(out amount, 1200, 12));
            Console.WriteLine("Total Amount including GST {0}",amount);
        }
    }
}
