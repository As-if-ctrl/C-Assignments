﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6.Properties
{
    class Student
    {
        public void StudentDetails(int rollNo, string Name)
        {
            if(rollNo < 100 || Name=="")
            {

                throw new InvalidStudentCode();
            }
        }
    }
}
