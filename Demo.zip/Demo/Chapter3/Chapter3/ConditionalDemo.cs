﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class ConditionalDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter higher qualification (UG | PG)");
            string qualification = Console.ReadLine();
            Console.WriteLine("Enter experience in months:");
            int Month = Convert.ToInt32(Console.ReadLine());
            if (qualification == "PG" && Month >= 12)
            {
                Console.WriteLine("you are eligible for interview");
            }
            else
            {
                Console.WriteLine("you are not eligible for interview ");
            }
            Console.ReadLine();
        }
    }
}
