﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    struct CitySTDcode
    {
        public enum city
        {
            Nagar=0240,Pune=0220,Mumbai=0200
        }
    }
}
