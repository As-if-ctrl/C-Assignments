﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class FactorialAss1
    {
        //Calling Factorials function from FactorialMain Class
        public int Factorials(int num)
        {
            int fact = 1;


            if (num != 0)
            {
                for (int i = 1; i <= num; i++)
                {
                    fact = fact * i;
                }
            }
            else
            {
                return fact;
            }


            return fact;
        }
    }
}
