﻿using System;


namespace Assignment1
{
    public static class FindPositiveNegative
    {
        public static bool IsPostive(this int i, int value)
        {
            return i >= 0;
        }


        static void Main(string[] args)
        {
            int i = Convert.ToInt32(Console.ReadLine());
            int v = Convert.ToInt32(Console.ReadLine());
            if (i.IsPostive(v))
            {
                Console.WriteLine(i + v);
            }
            else
            {
                Console.WriteLine("Number is negative");
            }
            //bool result = i.IsPostive(v);
            //Console.WriteLine(result ? "Positive" : "Negative");
            Console.ReadLine();
        }
    }
}
