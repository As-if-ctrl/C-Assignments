﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class MyMath
    {
        public void Message()
        {
            Console.WriteLine("This is test Message");
        }

        public int Add(int num1, int num2)
        {
            return num1 /num2;
        }

        public double Add(double d1,double d2)
        {
            return d1 + d2;
        }

        public int Increment(int x)
        {
            x++;
            return x;
        }

        public int Increment(ref int x)//x=num
        {
            x++;//num++
            return x;
        }

        public int MyFunction(out int x, int x1, out int z, int z1)
        {
            x = x1;
            z = z1;
            int y = 100;
            return y;
        }

        public double GST(out double TotalAmount, double amount, double gstPercentage)
        {
            double gstAmount = (amount * gstPercentage / 100);
            TotalAmount = gstAmount + amount;
            return gstAmount;
        }

        public string Size(int Height,int Width = 1,string msg="Size is:")
        {
            return string.Format("{0} {1}",msg, Height * Width);
        }

        //Using params keyword
        public void Marks(params int[] marks)
        {
            foreach(int temp in marks)
            {
                Console.WriteLine(temp);
            }
        }

    }
}
