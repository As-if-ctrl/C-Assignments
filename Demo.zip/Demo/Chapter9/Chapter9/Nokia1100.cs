﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class Nokia1100:Nokia1400
    {
        public Nokia1100()
        {
            Console.WriteLine("Default Constructor Nokia1100");
        }

        public string MP3()
        {
            return "Calling mp3 from Nokia1100";
        }
    }
}
