﻿using System;


namespace Assignment1
{
    abstract class Computer
    {
        public string BootUp()
        {
            return "Machine running in Bootup process....";
        }

        public string ShutDwon()
        {
            return "Machine start shutdwon";
        }
    }

    class SuperComputer : Computer
    {
        public SuperComputer()
        {
            Console.WriteLine("SuperCmputer Constructor...");
        }
    }

    class MainfraimComputer : Computer
    {
        public MainfraimComputer()
        {
            Console.WriteLine("MainfraimComputer Constructor...");
        }
    }

    class MicroComputer : Computer
    {
        public MicroComputer()
        {
            Console.WriteLine("MicroComputer Constructor...");
        }
    }
}
