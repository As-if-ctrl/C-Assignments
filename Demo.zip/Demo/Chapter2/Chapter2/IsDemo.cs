﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class IsDemo
    {
        static void Main()
        {
            int num = 10;
            int num1 = 30;
            object num2 = 88;
            Console.WriteLine(num2 is int);
            Console.WriteLine(num is int);
            Console.WriteLine(num1 is int);
            Class1 c1 = new Class1();//Base class
            Class2 c2 = new Class2();//Drive class
            Console.WriteLine(c2 is Class1);//True
            Console.WriteLine(c1 is Class2);//False
            Console.ReadLine();
        }

    }
}
