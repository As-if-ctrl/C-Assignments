﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class FunOverloadingDemo
    {
       static void Main()
        {
            MyMath m = new MyMath();
            Console.WriteLine(m.Add(2,4));
            Console.WriteLine(m.Add("2","5"));
        }
    }
}
