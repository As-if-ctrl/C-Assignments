﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class OutDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            int num;
            int num1;
            Console.WriteLine(m.MyFunction(out num, 90, out num1, 110));
            Console.WriteLine(num);
            Console.WriteLine(num1);
            

            //int a;
            //string str = "20";
            //int.TryParse(str, out a);
            //Console.WriteLine(a);
        }
    }
}
