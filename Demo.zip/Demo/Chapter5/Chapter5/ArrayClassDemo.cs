﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class ArrayClassDemo
    {
        static void Main()
        {
            int[] nums = { 11, 3, 1, 9, 12 };
            int[] dums = new int[5];
            int[,] nums1 = new int[2, 3];
            int[,] dums1 = new int[1, 5];
            nums.CopyTo(dums, 0);
            Console.WriteLine("After copied element from nums to dums:");
            foreach(int temp in dums)
            {
                Console.WriteLine(temp);
            }

            nums.SetValue(99, 4);
            Console.WriteLine("After replacing 12 with 99:");
            foreach (int temp in nums)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("Value at index 4 is {0}", dums.GetValue(4));
            Console.WriteLine("Upperbound for dums is {0}", dums.GetUpperBound(0));
            Console.WriteLine("Upperbound for nums1(0) is {0} and nums(1) is {1} ", nums1.GetUpperBound(0), nums1.GetUpperBound(1));
            Console.WriteLine("Numbers of dim are {0}", nums1.Rank);

            //Array.Copy(nums, dums1, 5);
            //foreach(int temp in dums1)
            //{
            //    Console.WriteLine(temp);
            //}

            Array.Sort(nums);
            Console.WriteLine("After sorting nums:");
            foreach (int temp in nums)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("Index of element 1 is {0}", Array.IndexOf(nums1, 1));
            Array.Reverse(nums);
            foreach(int temp in nums)
            {
                Console.WriteLine(temp);
            }
        }
    }
}
