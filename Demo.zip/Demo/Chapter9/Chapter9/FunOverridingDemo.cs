﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class FunOverridingDemo
    {
        static void Main()
        {
            MyMath2 m2 = new MyMath2();
            Console.WriteLine(m2.Increment(2));
        }
    }
}
