﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class TwoD_ArrayAss5
    {
        /// <summary>
        /// Print 2-D Array of Character ASCII value
        /// </summary>
        static void Main()
        {
            char ch1 = 'a';
            int ascii = Convert.ToInt32(ch1);
            Console.WriteLine(ascii);
            int[][] arr = new int[3][];
            arr[0] = new int[3];
            arr[1] = new int[3];
            arr[2] = new int[3];

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (ascii % 3 != 0)
                    {
                        arr[i][j] = ascii;
                    }
                    else
                    {
                        arr[i][j] = ascii;
                    }
                    ascii++;
                }
            }
            Console.WriteLine("Show the jagged array:");
            for (int i = 0; i < 3; i++)
            {
                foreach (int temp in arr[i])
                {
                    Console.Write("{0}\t", temp);
                }
                Console.WriteLine();
            }
        }
    }
}
