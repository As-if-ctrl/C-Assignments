﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class ByValueByRefDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            
                int num = 99;
;               Console.WriteLine(m.Increment(ref num));
            Console.WriteLine(num);
        }
    }
}
