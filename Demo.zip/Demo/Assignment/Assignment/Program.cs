﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            FactorialAss1 f = new FactorialAss1();
            Console.WriteLine("Enter the Factorial number");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"{f.Factorials(n)}");
        }
    }
}
