﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class GenricsDemo
    {
        static void Main()
        {
            Queue<int> q = new Queue<int>();
            q.Enqueue(12);
            foreach(int i in q)
            {
                Console.WriteLine(i);
            }

            Stack<int> stk = new Stack<int>();
            stk.Push(10);
            stk.Push(20);
            foreach (int i in stk)
            {
                Console.WriteLine(i);
            }
        }
    }
}
