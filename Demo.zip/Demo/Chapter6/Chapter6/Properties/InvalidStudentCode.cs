﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6.Properties
{
    class InvalidStudentCode:Exception
    {
        public InvalidStudentCode() : base("invalid Student roll no. or Empty Name")
        {

        }
    }
}
