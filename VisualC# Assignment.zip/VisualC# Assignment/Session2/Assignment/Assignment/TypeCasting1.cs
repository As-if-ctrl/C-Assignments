﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class TypeCasting1
    {
        static void Main()
        {
            Console.WriteLine("Enter character:");
            char ch = Convert.ToChar(Console.ReadLine());
            int ascii = ch;
            Console.WriteLine("Enter ascii value");
            int ascii1 = Convert.ToInt32(Console.ReadLine());
            char ch1 = (char)ascii1;
            Console.WriteLine("ASCII value of char: {0}  \ncharacter of ASCII value: {1} ", ascii, ch1);
            Console.ReadLine();

        }
    }
}
