﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
    class Hierarachy
    {
        static void Main()
        {
            Nokia1400 nk1 = new Nokia1400();
            Nokia2700 nk2 = new Nokia2700();
            Console.WriteLine(nk1.Calling());
            Console.WriteLine(nk1.Radio());
            Console.WriteLine(nk2.MP4());
            Console.WriteLine(nk2.Camera());
            Console.ReadLine();
        }
    }
}
