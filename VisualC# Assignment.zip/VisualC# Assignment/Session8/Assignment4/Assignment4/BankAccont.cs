﻿using System;

namespace Assignment4
{
    interface BankAccont
    {
        void Deposit(double amount);
        void Withdraw(double amount);
    }
}
